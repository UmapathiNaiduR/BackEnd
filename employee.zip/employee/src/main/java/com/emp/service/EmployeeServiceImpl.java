package com.emp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.entity.EmployeeEntity;
import com.emp.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;
	
	//POSTing
	@Override
	public EmployeeEntity saveDetails(EmployeeEntity employeeEntity) {
		return employeeRepository.save(employeeEntity);
	}

	//FetchingALL/GETting
	@Override
	public List<EmployeeEntity> getDetails() {
		return employeeRepository.findAll();
	}

	//FetchByID
	@Override
	public EmployeeEntity fetchById(Long empID) {
		return employeeRepository.findById(empID).get();
	}

	//PUTting/Updating
	@Override
	public EmployeeEntity updateEntity(Long empID, EmployeeEntity employeeEntity) {
		EmployeeEntity obj = employeeRepository.findById(empID).get();
		
		if(obj != null) {		
		obj.setEmpName(employeeEntity.getEmpName());
		obj.setEmpEmail(employeeEntity.getEmpEmail());
	}
		return employeeRepository.save(employeeEntity);
}

	//DeletingById
	@Override
	public String deleteById(Long empID) {
		employeeRepository.deleteById(empID);
		return "Deleted Successfully";
	}
}
