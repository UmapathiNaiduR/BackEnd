package com.emp.service;

import java.util.List;
import java.util.Optional;

import com.emp.entity.EmployeeEntity;


public interface EmployeeService{

	EmployeeEntity saveDetails(EmployeeEntity employeeEntity);

	List<EmployeeEntity> getDetails();

	EmployeeEntity fetchById(Long empID);

	String deleteById(Long empID);

	EmployeeEntity updateEntity(Long empID, EmployeeEntity employeeEntity);

}
