package com.emp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emp.entity.EmployeeEntity;
import com.emp.service.EmployeeService;

@RestController
@RequestMapping("/empl")
public class EmpController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/post")
	public EmployeeEntity saveDetail (@RequestBody EmployeeEntity employeeEntity) {
		return employeeService.saveDetails(employeeEntity);
	}
	
	
	@GetMapping("/get" )
	public List<EmployeeEntity> getDetails(){
		return employeeService.getDetails();
	}
	
	
	@GetMapping("/get/{empID}")
	public EmployeeEntity fetchById(@PathVariable("empID") Long empID) {
		return employeeService.fetchById(empID);	
	}
	
	
	@DeleteMapping("/del/{empID}")
	public String deleteById(@PathVariable("empID") Long empID) {
		 employeeService.deleteById(empID);
		 return "Deleted Successfully";		
	}

	
	@PutMapping("/update/{empID}")
	public EmployeeEntity updateEntity(@PathVariable("empID") Long empID, @RequestBody EmployeeEntity employeeEntity) {
		return employeeService.updateEntity(empID, employeeEntity);
	}
	
	
}
