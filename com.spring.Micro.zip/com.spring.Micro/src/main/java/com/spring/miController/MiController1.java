package com.spring.miController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MiController1 {
	
	@GetMapping("/name")
	public String Name() {
		System.out.println("jhvdhcgvsjcvsjhcv");
		return "success";
		
		
	}

}
